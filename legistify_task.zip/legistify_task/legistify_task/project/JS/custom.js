  $(document).ready(function(){
    $("#Education_button").click(function(){
    	clone_details = jQuery("#education_clone").clone();         
        clone_details.css({'position':'relative','margin-bottom':'2%'});
        // jQuery("#details-child").css('background','blue'); // changes original div

    // render clone
        $("fieldset").append(clone_details);
       
    });
	$("#user_details").validate({

			rules: {
			name: "required",
			 email: {
                        required: true,
                        email: true
                    },
               password: {
                        required: true,
                        minlength: 5
                    },

			},

			messages: {
			   name: "Please enter your first name",
			   password: {
                        required: "Please provide a password",
                        minlength: "Your password must be at least 5 characters long"
                    },
                    email: "Please enter a valid email address"
			},
			errorElement : 'div',
            errorLabelContainer: '.errorTxt'

	});	
$("#graduation_year").keyup(function(){
	  if($("#user_details").valid()){   // test for validity
            alert("polling");
			$("#user_next").attr('disabled',false);
        } else {
            // do stuff if form is not valid
            alert("mopolling");
        }	
	});
});	
 $(document).ready(function(){
		$("#legal_info").validate({

			rules: {
			court_field: "required",
			state: "required",
	
			},

			messages: {
			   court_field: "Please enter your court name",
			   state: "Enter a state",
			},
			errorElement : 'div',
            errorLabelContainer: '.errorTxt'

	});	
$("#address").keyup(function(){
	  if($("#legal_info").valid()){   // test for validity
            alert("polling");
			$("#legal_next").attr('disabled',false);
        } else {
            // do stuff if form is not valid
            alert("mopolling");
        }	
	});
});
$(document).ready(function(){
		$("#basic_info").validate({

			rules: {
			summary:{ required:true,
			          minlength: 160
					},
			job: "required",
	        company_name: "required",
			from: "required",
			job1: "required",
	        company_name1: "required",
			from1: "required",
			title_field: "required",
	
			},

			messages: {
			summary:{ required:"Summary required",
			          minlength: "Minimun length is 160"
					  },
					  
			   job: "Please your job",
	        company_name: "Please enter the company name",
			from: "please fill in the details",
			job1: "Please provide honours college name",
	        company_name1: "Please enter grnated by field",
			from1: "please enter duration",
			title_field: "Please enter the title",
			},
			errorElement : 'div',
            errorLabelContainer: '.errorTxt'

	});	
$("#year_field").keyup(function(){
	  if($("#basic_info").valid()){   // test for validity
            alert("polling");
			$("#basic_next").attr('disabled',false);
        } else {
            // do stuff if form is not valid
            alert("mopolling");
        }	
	});
});
$(document).ready(function(){
    $("#experience_button").click(function(){
    	clone_details = jQuery("#experie_clone").clone();         
        clone_details.css({'position':'relative', 'left':'20%','margin-bottom':'2%'});
        // jQuery("#details-child").css('background','blue'); // changes original div

    // render clone
        $(clone_details).appendTo("#exp_cloned");
       
    });
    
});
$(document).ready(function(){
		$("#Bar_info").validate({

			rules: {
			
			bar_id: "required",
	        
			},

			messages: {
			
			bar_id: "Bar id required",
	      

			},
			errorElement : 'div',
            errorLabelContainer: '.errorTxt'

	});	
$("#year").keyup(function(){
	  if($("#Bar_info").valid()){   // test for validity
            alert("polling");
			$("#bar_finish").attr('disabled',false);
        } else {
            // do stuff if form is not valid
            alert("mopolling");
        }	
	});
});
  $(document).ready(function(){
    $("#legal_button").click(function(){
    	clone_details = jQuery("#court_clone").clone();         
        clone_details.css({'position':'relative', 'left':'20%','margin-bottom':'2%'});
        // jQuery("#details-child").css('background','blue'); // changes original div

    // render clone
        $(clone_details).appendTo("#crt_cloned");
       
    });
    
});

  $(document).ready(function(){
    $("#honours_button").click(function(){
    	clone_details = jQuery("#honours_clone").clone();         
        clone_details.css({'position':'relative', 'left':'20%','margin-bottom':'2%'});
        // jQuery("#details-child").css('background','blue'); // changes original div

    // render clone
        $(clone_details).appendTo("#hon_cloned");
       
    });
    
});

  $(document).ready(function(){
    $("#publication_button").click(function(){
    	clone_details = jQuery("#publication_clone").clone();         
        clone_details.css({'position':'relative', 'left':'20%','margin-bottom':'2%'});
        // jQuery("#details-child").css('background','blue'); // changes original div

    // render clone
        $(clone_details).appendTo("#pub_cloned");
       
    });
    
});

  $(document).ready(function(){
    $("#barinfo_button").click(function(){
    	clone_details = jQuery("#year_clone").clone();         
        clone_details.css({'position':'relative', 'left':'20%','margin-bottom':'2%'});
        // jQuery("#details-child").css('background','blue'); // changes original div

    // render clone
        $(clone_details).appendTo("#yr_cloned");
       
    });
    
});

$(document).ready(function(){
    $("#user_next").click(function(e){
        jQuery('#ch1').attr('checked', true);   
    	$("#legal_info").show();
		$("#user_details").hide();
		e.preventDefault();
    });
});

$(document).ready(function(){
    $("#legal_next").click(function(e){
		jQuery('#ch2').attr('checked', true);   
    	$("#legal_info").hide();
		$("#basic_info").show();
		e.preventDefault();
       
    });
});

$(document).ready(function(){
    $("#basic_next").click(function(e){
		jQuery('#ch3').attr('checked', true);   
    	$("#basic_info").hide();
		$("#Bar_info").show();
		e.preventDefault();
       
    });
});

$(document).ready(function(){
    $("#basic_back").click(function(e){
    	$("#basic_info").hide();
		$("#legal_info").show();
		e.preventDefault();
       
    });
});

$(document).ready(function(){
    $("#bar_back").click(function(e){
    	$("#Bar_info").hide();
		$("#basic_info").show();
		e.preventDefault();
       
    });
});
$(document).ready(function(){
	$("#bar_finish").click(function(e){
jQuery('#ch4').attr('checked', true);
window.location.href="profile1.html"
});
});